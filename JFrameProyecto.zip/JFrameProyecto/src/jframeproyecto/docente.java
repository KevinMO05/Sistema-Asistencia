package jframeproyecto;

import javax.swing.JTextField;

public class docente {

    private String DNI;
    private String Nombre;
    private String Apellidos;
    private String Sexo;
    private String aula;
    private String clave;
    private String horaEntrada;
    private String horaSalida;

    public docente(String DNI, String Nombre, String Apellidos, String Sexo, String aula, String clave, String horaEntrada, String horaSalida) {
        this.DNI = DNI;
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Sexo = Sexo;
        this.aula = aula;
        this.clave = clave;
        this.horaEntrada = horaEntrada;
        this.horaSalida = horaSalida;
    }

    public docente() {

    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellidos() {
        return Apellidos;
    }

    public void setApellidos(String Apellidos) {
        this.Apellidos = Apellidos;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }

    public String getAula() {
        return aula;
    }

    public void setAula(String aula) {
        this.aula = aula;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getHoraEntrada() {
        return horaEntrada;
    }

    public void setHoraEntrada(String horaEntrada) {
        this.horaEntrada = horaEntrada;
    }

    public String getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(String horaSalida) {
        this.horaSalida = horaSalida;
    }

    @Override
    public String toString() {
        return """
               docente{ 
                DNI= """ + DNI + "\n"
                + ", Nombre = " + Nombre + "\n"
                + ", Apellidos = " + Apellidos + "\n"
                + ", Sexo = " + Sexo + "\n"
                + ", Aula = " + aula + "\n"
                + ", Clave = " + clave + "\n"
                + ", Hora de entrada = " + horaEntrada + "\n"
                + ", Hora de salida = " + horaSalida + '}' + "\n" + "\n";
    }

}
